#include "Dice.h"

void Dice::RollDice()
{}
void Dice::DisplayDice()
{}