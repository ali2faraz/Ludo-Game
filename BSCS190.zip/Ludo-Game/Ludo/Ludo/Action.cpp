#include "Action.h"

void Action::Endgame()
{}
void Action::MovePiece()
{}
void Action::Nothing()
{}

