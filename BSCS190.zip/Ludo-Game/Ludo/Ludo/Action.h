#pragma once
class Action
{
public:
	void Nothing();
	void MovePiece();
	void Endgame();
};

