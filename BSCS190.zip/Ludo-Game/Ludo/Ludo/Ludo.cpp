#include "Ludo.h"

void Ludo::Init()
{}
void Ludo::StartScreen()
{}
void Ludo::GetMove()
{}
bool Ludo::IsLegalMove()
{
	return true;
}
void Ludo::StartGame()
{}
bool Ludo::IsGameOver()
{
	return true;
}
void Ludo::TurnChange()
{}
void Ludo::UpdatePlayerPosition()
{}