#pragma once
class Stops
{
public:
	bool IsSafeZone();

};

