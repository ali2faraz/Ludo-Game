#include "Box.h"
#include<iostream>
using namespace std;

Box::Box()
{

}
Box::~Box()
{

}
void Box::AddPiece()
{

}
void Box::RemovePiece()
{

}
void Box::SetColour()
{

}
void Box::SetGoal()
{

}
void Box::SetHouse()
{

}
void Box::SetNumber()
{

}
