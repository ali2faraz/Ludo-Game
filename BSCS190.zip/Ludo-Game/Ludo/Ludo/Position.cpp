#include "Position.h"
Position::Position(int L_r, int L_c)
{
	this->r = L_r;
	this->c = L_c;
}
int Position::getr()
{
	return this->r;
}
int Position::getc()
{
	this->c;
}