#include "View.h"
#include<iostream>
using namespace std;
View::View()
{

}
View::~View()
{

}
void View::StartGame()
{

}
void View::EndGame()
{

}
void View::InitBoard()
{

}
void View::RollDice()
{

}
void View::DisableDice()
{

}
void View::UpdateBoard()
{

}