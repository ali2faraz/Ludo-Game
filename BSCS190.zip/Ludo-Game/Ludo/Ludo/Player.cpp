#include "Player.h"
Player::Player()
{

}
Player::Player(Color c)
{
	this->co = c;
}
void Player::SetPieceStatus()
{

}
void Player::draw()
{

}
void Player::SetPieceNumber()
{

}
void Player::GetPieceNumber()
{

}
void Player::SetColor()
{

}
void Player::SetWon()
{

}
void Player::IsWin()
{

}
bool Player::IsLegalMove()
{
	return true;
}
