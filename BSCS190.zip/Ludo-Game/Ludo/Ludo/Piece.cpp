#include "Piece.h"


Piece::Piece()
{

}

void Piece::setcolor(char c)
{

}

int Piece::getcolor()
{

}

void Piece::reset()
{

}
