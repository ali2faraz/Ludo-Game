#include "Stops.h"

bool Stops::IsSafeZone()
{
	return true;
}

