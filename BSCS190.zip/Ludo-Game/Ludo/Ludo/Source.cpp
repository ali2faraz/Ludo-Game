#include<iostream>
#include"View.h"
using namespace std;

int main()
{
	View Game;
	Game.StartGame();
	return 0;
}